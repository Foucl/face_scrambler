Face Scrambler
===============================

version number: 0.0.1
author: Christopher Dannheim

Overview
--------

Python package that creates scrambled versions of images of human faces.

Installation / Usage
--------------------

To install use pip:

    $ pip install face_scrambler


Or clone the repo:

    $ git clone https://github.com/Foucl/face_scrambler.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD